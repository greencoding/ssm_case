create definer = root@localhost trigger ins_trigger
    after insert
    on users
    for each row
    INSERT INTO users_role(userId,roleId) VALUES(new.id,3);

